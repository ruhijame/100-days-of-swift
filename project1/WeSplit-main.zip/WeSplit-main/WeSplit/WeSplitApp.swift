//
//  WeSplitApp.swift
//  WeSplit
//
//  Created by Ruhi Jame on 6/4/25.
//

import SwiftUI

@main
struct WeSplitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
